(function() {
  'use strict';

  // Safari, in Private Browsing Mode, looks like it supports localStorage but all calls to setItem
  // throw QuotaExceededError. We're going to detect this and just silently drop any calls to setItem
  // to avoid the entire page breaking, without having to do a check at each usage of Storage.
  if (typeof localStorage === 'object') {
      try {
          localStorage.setItem('localStorage', 1);
          localStorage.removeItem('localStorage');
      } catch (e) {
          Storage.prototype._setItem = Storage.prototype.setItem;
          Storage.prototype.setItem = function() {};
          alert('Your web browser does not support storing settings locally. In Safari, the most common cause of this is using "Private Browsing Mode". Some settings may not save or some features may not work properly for you.');
      }


  }

  function endall(transition, callback) {
	    if (transition.size() === 0) { callback(); }
	    var n = 0;
	    transition
	        .each(function() { ++n; })
	        .each("end", function() { if (!--n) callback.apply(this, arguments); });
	  }

	angular.module('homepage', ['yepchat'])
  .constant('PinSize', 50)
  .constant('ZoomScale', 600)
  .directive('delayedShow', ['$timeout',function($timeout){
    var directive ={

      link:function(s,e,a){
        e.css('opacity', '0');
        e.addClass('delay-active');
        var delay= a.delayedShow;
        $timeout(function(){
          e.css('opacity',1);
        }, delay);

      }
    };
    return directive;
  }])
  .directive('conversationDisplay', ['$http','AppContext', function($http, AppContext){
    var directive = {
      restrict:'E',
      scope:{
        conversation:'='
      },
      templateUrl:AppContext+'dynamic/templates/conversation-display.jsp',
      link:function(s,e,a){
      }
    };
    return directive;

  }])
  .directive('conversationShuffle', ['$http','AppContext', '$compile', '$interval', '$timeout', '$rootScope',
    function($http, AppContext,$compile, $interval, $timeout, $rootScope){

    var directive = {
      restrict:'E',
      scope:{
        conversations:'='
      },
      templateUrl:AppContext+'dynamic/templates/conversation-shuffle.jsp',
      link:function(s,e,a){
        var currentElement;
        function createNewConvo(event, whichConvo){
          var width = window.innerWidth;
          angular.element('.removed').remove();
          e.find('conversation-display').css('opacity', 0);
          e.find('conversation-display').addClass('removed');
          $timeout(function () {
            var left = $('image').position().left + 55;
            var top = $('image').position().top +25;

            if(width <  630)
            {
              left = 20;
              top = 85;
              e.find('.container').append($compile('<conversation-display style="top:'+top+'px;right:'+left+'px" conversation="conversations['+whichConvo+'].messages"></conversation-display>')(s));

            }
            else{
              e.find('.container').append($compile('<conversation-display style="top:'+top+'px;left:'+left+'px" conversation="conversations['+whichConvo+'].messages"></conversation-display>')(s));

            }

          }, 3000);
        }
        $rootScope.$on('moveStarted',createNewConvo);



      }
    };
    return directive;

  }])
  .controller('ConversationPopinsCtrl', ['$http', '$q', '$scope', '$rootScope', 'PinSize', 'ZoomScale', 'conversations', '$compile', '$timeout', function($http, $q, $scope, $rootScope, PinSize, ZoomScale, conversations, $compile, $timeout){
    this.testConversations = conversations;
    $scope.conversations = conversations;

    function getHeightOfConversation(whichConversation){

      var measuringBox = '<conversation-display style="opacity:0;" class="removed" conversation="conversations['+whichConversation+'].messages"></conversation-display>';
      measuringBox = angular.element(measuringBox);
      measuringBox.appendTo(angular.element('body'));
      $compile(measuringBox)($scope);

      var promise = $timeout(0).then(function(){
          return  measuringBox.height();
      });

      return promise;
    }

		var animateTo;
		var width = $('svg').width() ;
		var height =$('svg').height();
		var xOffest;
		var scale = (width * 1.2);
		scale = scale < 600 ? scale : 600;

		var projection = d3.geo.mercator()
					.center([-118,34])
					.rotate([0,0])
					.scale(1200)
				.translate([width/2, height/2]);

		var path = d3.geo.path()
				.projection(projection);



		var graticule = d3.geo.graticule();

		var svg = d3.select("svg")
				.attr("width", width)
				.attr("height", height);
		$( window ).resize(function() {
			width = window.innerWidth ;
			height = window.innerHeight -100;

			svg.attr("width", width)
			.attr("height", height);
		});

		var g = svg.append("g");
		function interpolatedProjection(a, b) {
			  var projection = d3.geo.projection(raw).scale(1),
			      center = projection.center,
			      translate = projection.translate,
			      alpha;

			  function raw(lamba, phi) {
			    var pa = a([lamba *= 180 / Math.PI, phi *= 180 / Math.PI]), pb = b([lamba, phi]);
			    return [(1 - alpha) * pa[0] + alpha * pb[0], (alpha - 1) * pa[1] - alpha * pb[1]];
			  }
			    var ca = a.center(), cb = b.center(),
		        ta = a.translate(), tb = b.translate();
			  projection.alpha = function(_) {
			    if (!arguments.length) return alpha;
			    alpha = +_;

			    center([(1 - alpha) * ca[0] + alpha * cb[0], (1 - alpha) * ca[1] + alpha * cb[1]]);
			    translate([(1 - alpha) * ta[0] + alpha * tb[0], (1 - alpha) * ta[1] + alpha * tb[1]]);
			    return projection;
			  };

			  delete projection.scale;
			  delete projection.translate;
			  delete projection.center;
			  return projection.alpha(0);


      }
			}
      $q.all([
        $q.all([
      		$http.get("static/assets/json/world-110m2.json"),
          $http.get("static/assets/json/ne_110m_admin_1_states_provinces_shp_scale_rank.topojson")

        ]).then(function(results){
          var topology = results[0].data;

          var data = topojson.object(topology, topology.objects.countries)
              .geometries;

          var newData = [];
          for(var i = 0; i<data.length; i++){
            var cur = data[i];

                var maxX =d3.max(cur.coordinates[0], function(array) {

                  if(cur.type=="MultiPolygon")
                {
                  return d3.max(array, function(innerarray){return innerarray[0];});
                }


                  return array[0];
                });
                var minY = d3.max(cur.coordinates[0], function(array) {

                  if(cur.type=="MultiPolygon")
                {
                  return d3.max(array, function(innerarray){return innerarray[1]})
                }
                  return array[1];
                });
                if(minY > -40 && maxX < 20 )
              {
                  newData.push(cur);
                }
          }
          var stateData = topojson.object(results[1].data, results[1].data.objects.layer1).geometries;
          stateData.map(function(state){
        	  state.isState = true;
          });
          newData = newData.concat(stateData);
            g.selectAll("path")
              .data(newData)
            .enter()
              .append("path")
              .attr("d", path)
              .attr("class", function(item){
            	  return item.isState ? "state" : "country";
              });

          var feature = svg.selectAll("path");
          var oldCenter = [-118,34];
          var oldScale = 600;
          var first = true;



          animateTo = function(center, scale) {
            var width = $('svg').width() ;
            var height =$('svg').height();
            projection = interpolatedProjection(
                d3.geo.mercator()
                 .center(oldCenter)
                 .rotate([0,0])
                 .scale(oldScale * 2)
               .translate([width/2, height/2]),

               d3.geo.mercator()
                 .center(center)
                 .rotate([90,0])
                 .scale(scale )
               .translate([width/2, height/2])
               );

            path = d3.geo.path().projection(projection);
            oldCenter = center;
            var scaleDelta = Math.abs(scale - oldScale);
            oldScale = scale;

             svg.transition()
                .duration(scaleDelta + 2000)
                .tween("projection", function() {
                  return function(_) {

                   projection.alpha(_);
                      var width = (PinSize) - (PinSize/2) * _;
                      var height =  (PinSize) - (PinSize/2) * _;
                      svg.selectAll("image")
                      .attr("x", function(d) {
                            return projection([d.longitude, d.latitude])[0] -width/2;
                        })
                        .attr("y", function(d) {
                                return projection([d.longitude, d.latitude])[1] - height/2;
                        })
                        .attr('width', width)
                        .attr('height', height);

                      feature.attr("d", function(vals){
                        var curpath = path.apply(this, arguments);

                      if(curpath.indexOf('NaN') !== -1 || curpath.indexOf('Infinity') !== -1){
                          return '';
                        }

                        return curpath;
                      });				        };
                }).call(endall, function(){
                projection = interpolatedProjection(
                    d3.geo.mercator()
                     .center(center)
                     .rotate([0,0])
                     .scale(scale)
                   .translate([width/2, height/2]),

                   d3.geo.mercator()
                     .center(center)
                     .rotate([0,0])
                     .scale(scale*2)
                   .translate([width/2, height/2])
                   );
                path = d3.geo.path().projection(projection);


                  svg.transition()
                  .duration(1000)
                  .tween("projection", function() {
                    return function(_) {

                     projection.alpha(_);
                      var width = (PinSize/2) + (PinSize/2) * _;
                      var height =  (PinSize/2) + (PinSize/2) * _;
                      svg.selectAll("image").attr("x", function(d) {
                            return projection([d.longitude, d.latitude])[0] - width/2;
                        })
                        .attr("y", function(d) {
                                return projection([d.longitude, d.latitude])[1] - height/2;
                        })
                        .attr('width', width)
                        .attr('height', height);

                        feature.attr("d", function(){
                          var curpath = path.apply(this, arguments);

                          if(curpath.indexOf('NaN') !== -1 || curpath.indexOf('Infinity') !== -1){
                            return '';
                          }

                          return curpath;
                        });
                    };
                  });
                });
          };
          return results;
        }),

]).then(function(){
    function renderCity(ignore){
      var self = this;
    	var width = $('svg').width();
    	var height = $('svg').height();

      var whichConvo = localStorage.currentConvo ? parseInt(localStorage.currentConvo) : Math.floor(Math.random()*conversations.length);
      whichConvo = whichConvo < conversations.length - 1 ? whichConvo + 1 : 0;
      localStorage.currentConvo = whichConvo;

      var city = conversations[whichConvo].city;

    getHeightOfConversation(whichConvo).then(function(conversationheight){
      if(ignore)return;

      var zprojection = d3.geo.mercator()
          .center([city.longitude,city.latitude])
          .rotate([0,0])
          .scale(scale * 2)
          .translate([width/2, height/2]);
      var pinConsideration = PinSize;

      var cdWidth = width * 0.8 < 350 ? width * 0.8 :350;
      var minOffset = pinConsideration;
      var xvariance =( 3) * ( (width - cdWidth - pinConsideration)/5); //Left 1/5 - 3/5 of map
      xvariance = xvariance > minOffset *1.5 ? xvariance : minOffset*1.5;
      var yvariance =( 2.5) * ( (height  - PinSize*2 - conversationheight -  $('.header').height())/5); //Top 2/5 - 3/5 of map
      // yvariance = 0;
      // xvariance = 0;

      if((yvariance < 0 || (conversationheight > height - 85)) && (height > 300 ||  conversations[whichConvo].messages.length > 2 || conversations[whichConvo].messages[0].length > 160))
      {
        renderCity();
        return;
      }
      else if(yvariance < $('.header').height()+ PinSize){
        yvariance = $('.header').height() +PinSize;
      }
      console.log(yvariance);
      var zx = width - xvariance;
      var zy = height - yvariance;
      if(width <  630)
      {
        zx = width - 25 - PinSize;
        zy = height - 70 - PinSize;
      }
      // var xvariance =0 * ( (width - cdWidth - pinConsideration*2)/5);
      // console.log(xvariance, $('.conversation-display'), $('.conversation-display').width(), ( width - $('.conversation-display').width() - PinSize*2));
      // console.log(PinSize, $('.header').height())
      var zpos = zprojection.invert([zx, zy]);

      var xoffset = zpos[0];
      var yoffset = zpos[1];

      animateTo([xoffset, yoffset], 600);
      if(!ignore){
        $rootScope.$broadcast('moveStarted', whichConvo);

        setTimeout(function(){
          var iconRef;

          switch (conversations[whichConvo].type) {
            case "Gym":
              iconRef = "/static/assets/images/icon_pin_gym.svg";
              break;
            case "Restaurant":
              iconRef = "/static/assets/images/icon_pin_restaurants.svg";

              break;
            default:
              iconRef = "/static/assets/images/icon_pin_retails.svg";

              break;

          }

         g.selectAll("image")
          .remove()

         g.selectAll("image")
          .data([city])
          .enter()
        .append("image")
          .attr("x", function(d) {
                  return projection([d.longitude, d.latitude])[0] - PinSize;
          })
          .attr("y", function(d) {
                  return projection([d.longitude, d.latitude])[1] - PinSize;
          })
          .attr('height', PinSize)
          .attr('width', PinSize)
          .attr("xlink:href",function(){
            return iconRef;
          })


          .style("fill", "steelblue");
          //  <image xlink:href="/files/2917/fxlogo.png" x="0" y="0" height="100" width="100" />

        }, 2000);


      }

    })


    }



      setInterval(renderCity,13000);
      renderCity(true);
      $timeout(renderCity,0);

//      $rootScope.$on('moveStarted', renderCity);

  });



    }])
  .constant('conversations',  [{"type":"Restaurant","city":{"city":"Dallas","growth_from_2000_to_2013":"5.6%","latitude":32.7766642,"longitude":-96.79698789999999,"population":"1257676","rank":"9","state":"Texas"},"messages":[{"manager":false,"body":"Great service and really amazing latte art! Always love getting my coffee"},{"manager":true,"body":"Love hearing that! Thank you for the positive feedback! Hope to see you soon!"}]},{"type":"Gym","city":{"city":"New York","growth_from_2000_to_2013":"4.8%","latitude":40.7127837,"longitude":-74.0059413,"population":"8405837","rank":"1","state":"New York"},"messages":[{"manager":false,"body":"Hi! Wondering if there is any chance we could get aerial yoga with silks? Also thanks for the sweet new Thursday night flow. It rules!"},{"manager":true,"body":"Glad to hear you're enjoying Strong Flow! As for aerial silks, nothing is ever a definite \"no,\" but for now we'll hold out until our renovations are finished. "}]},{"type":"Restaurant","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Your staff was very polite to me and that felt awesome."},{"manager":true,"body":"Thanks so much! Have a great day😀"}]},{"type":"Restaurant","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Just ate breakfast here, the breakfast bowl is awesome"},{"manager":true,"body":"Hi! Sorry for the delayed response - glad you enjoyed! See you back soon!"}]},{"type":"Gym","city":{"city":"San Jose","growth_from_2000_to_2013":"10.5%","latitude":37.3382082,"longitude":-121.8863286,"population":"998537","rank":"10","state":"California"},"messages":[{"manager":false,"body":"Friendly helpful staff. ..large, clean, and very nice climbing area, Locker room. Well kept weights, cardiovascular equipment"},{"manager":true,"body":"Thanks so much for your feedback! We're happy to hear you're enjoying everything, and we're trying to make improvements every day"}]},{"type":"Other","city":{"city":"New York","growth_from_2000_to_2013":"4.8%","latitude":40.7127837,"longitude":-74.0059413,"population":"8405837","rank":"1","state":"New York"},"messages":[{"manager":false,"body":"Your management is amazing :)"},{"manager":true,"body":"Thank you very much for your kind words, we appreciate your feedback immensely!"}]},{"type":"Restaurant","city":{"city":"Austin","growth_from_2000_to_2013":"31.7%","latitude":30.267153,"longitude":-97.7430608,"population":"885400","rank":"11","state":"Texas"},"messages":[{"manager":false,"body":"The girl at the register was incredibly rude to me and the women in my group who ordered. Today is 1/39 at 10:23am."},{"manager":true,"body":"Good Morning! I apologize - that's not like us. I'll make sure I talk to the team to make sure that doesn't happen again. I appreciate you reaching out and letting me know."}]},{"type":"Restaurant","city":{"city":"Houston","growth_from_2000_to_2013":"11.0%","latitude":29.7604267,"longitude":-95.3698028,"population":"2195914","rank":"4","state":"Texas"},"messages":[{"manager":false,"body":"Love the fact that you don't have loud music playing in the restaurant"},{"manager":true,"body":"Thanks, we're glad to hear that you appreciate the ambiance and we are grateful for your feedback. Hope you will join us again soon!"}]},{"type":"Restaurant","city":{"city":"Phoenix","growth_from_2000_to_2013":"14.0%","latitude":33.4483771,"longitude":-112.0740373,"population":"1513367","rank":"6","state":"Arizona"},"messages":[{"manager":false,"body":"Food was great! But please! Get a better house wine - Chardonnay was horrible! 😬😬😬 Maybe old???"},{"manager":true,"body":"Thanks for coming in. I'll look into it. Please let me know next time you're in ask for Daniel and I'll get you something to make up for the wine."}]},{"type":"Restaurant","city":{"city":"Austin","growth_from_2000_to_2013":"31.7%","latitude":30.267153,"longitude":-97.7430608,"population":"885400","rank":"11","state":"Texas"},"messages":[{"manager":false,"body":"Take out prep takes a bit too long."},{"manager":true,"body":"Sorry about the delay my staff informed me they wanted to make fresh ahi tuna since it is the end of the night. Enjoy your meal."},{"manager":false,"body":"No worries. It was fine."}]},{"type":"Restaurant","city":{"city":"Austin","growth_from_2000_to_2013":"31.7%","latitude":30.267153,"longitude":-97.7430608,"population":"885400","rank":"11","state":"Texas"},"messages":[{"manager":false,"body":"Just trying out the new location. Great customer service provided by Paige, who got me hooked on Nitro Cold Brew. My only concern is lack of Fair Trade which other coffee shops have. Please look into it as many of us are concerned about labor/environmental issues. Thanks!"},{"manager":true,"body":"Hi there! Thanks for coming in. All of our coffee is fair trade as well. Please check out our website for more info. Enjoy!"}]},{"type":"Gym","city":{"city":"Phoenix","growth_from_2000_to_2013":"14.0%","latitude":33.4483771,"longitude":-112.0740373,"population":"1513367","rank":"6","state":"Arizona"},"messages":[{"manager":false,"body":"To pay $200 a month and have machines not working for months is pathetic and inexcusable. Please fix the stairmaster!"},{"manager":true,"body":"I'm checking this out with my maintenance manager tomorrow. Keep you posted. We'll fix it. Sorry for the inconvenience!"}]},{"type":"Restaurant","city":{"city":"San Antonio","growth_from_2000_to_2013":"21.0%","latitude":29.4241219,"longitude":-98.49362819999999,"population":"1409019","rank":"7","state":"Texas"},"messages":[{"manager":false,"body":"Very slow and inefficient."},{"manager":true,"body":"We recently ordered a 2nd register to help get through the rush faster, and should have it up and running over the next week or two. Thanks for your feedback."}]},{"type":"Restaurant","city":{"city":"Anchorage","dma_code":743,"latitude":61.2180556,"longitude":-149.9002778,"region":"AK","slug":"anchorage-ak"},"messages":[{"manager":false,"body":"I ordered a latte and huevos rancheros and waited 25 minutes for the food to come out... Then brought it to their attention that my food still never came. Always have a great experience here... Server comped my drink but my entire meal should have been comped. Disappointed in the service here."},{"manager":true,"body":"Hi there! We are sorry for the mixup and would love to credit your next meal if you are interested. Please reply with your email address so that we can arrange. Thank you! :)"}]},{"type":"Gym","city":{"city":"Houston","growth_from_2000_to_2013":"11.0%","latitude":29.7604267,"longitude":-95.3698028,"population":"2195914","rank":"4","state":"Texas"},"messages":[{"manager":false,"body":"Please turn down the music on the workout floor. Most evenings it's so loud that I cannot hear my own music. It's too loud. Thx"},{"manager":true,"body":"On it right now"}]},{"type":"Restaurant","city":{"city":"Anchorage","dma_code":743,"latitude":61.2180556,"longitude":-149.9002778,"region":"AK","slug":"anchorage-ak"},"messages":[{"manager":false,"body":"Good morning! Positive and not positive feedback: Your coffee and food are exquisite and the service is usually excellent, although on my last two visits the same woman at the counter forgot my pour over. She had to be reminded and I had to sit for an extra 15 minutes. Otherwise, amazing."},{"manager":true,"body":"Thank you for reaching out! Do you happen to know the name of the person who helped you? I'd love to offer you a drink on us on your next visit. Thank you!"}]},{"type":"Other","city":{"city":"San Francisco","growth_from_2000_to_2013":"7.7%","latitude":37.7749295,"longitude":-122.4194155,"population":"837442","rank":"14","state":"California"},"messages":[{"manager":false,"body":"I've been a long time client of Tom. He always gives 110%"},{"manager":true,"body":"Thank you for letting us know and for being a loyal client!"}]},{"type":"Gym","city":{"city":"Los Angeles","growth_from_2000_to_2013":"4.8%","latitude":34.0522342,"longitude":-118.2436849,"population":"3884307","rank":"2","state":"California"},"messages":[{"manager":false,"body":"Please start enforcing the no cell phone policy. So tired of hearing everyone's phone conversations on the floor and the locker room. Has gotten really bad lately. Thanks!"},{"manager":true,"body":"I will make this a main topic for my managers meeting this Monday. We need to be better on this, thank you for your comment!"}]},{"type":"Gym","city":{"city":"San Antonio","growth_from_2000_to_2013":"21.0%","latitude":29.4241219,"longitude":-98.49362819999999,"population":"1409019","rank":"7","state":"Texas"},"messages":[{"manager":false,"body":"Women's restroom floors could use a good mopping. It's especially dirty by the showers and there's a small black buildup on the floor."},{"manager":true,"body":"Thank you for the heads up. Will have someone take care of that now."}]},{"type":"Gym","city":{"city":"Indianapolis","growth_from_2000_to_2013":"7.8%","latitude":39.768403,"longitude":-86.158068,"population":"843393","rank":"12","state":"Indiana"},"messages":[{"manager":false,"body":"I love Doug thank you for his yoga class"},{"manager":true,"body":"Thanks, we love Doug too! I'll be sure to pass along your positive comments!"}]},{"type":"Restaurant","city":{"city":"San Jose","growth_from_2000_to_2013":"10.5%","latitude":37.3382082,"longitude":-121.8863286,"population":"998537","rank":"10","state":"California"},"messages":[{"manager":false,"body":"Awesome place! Thank you for being up early to make my drink! :)"},{"manager":true,"body":"Thanks so much! Have a great day"}]},{"type":"Restaurant","city":{"city":"New York","growth_from_2000_to_2013":"4.8%","latitude":40.7127837,"longitude":-74.0059413,"population":"8405837","rank":"1","state":"New York"},"messages":[{"manager":false,"body":"Had the best latte! Love this place keep up the good work"},{"manager":true,"body":"Thanks a lot, we appreciate that immensely! Glad to hear you enjoyed your latte and we hope to have you back again soon."}]},{"type":"Restaurant","city":{"city":"San Diego","growth_from_2000_to_2013":"10.5%","latitude":32.715738,"longitude":-117.1610838,"population":"1355896","rank":"8","state":"California"},"messages":[{"manager":false,"body":"Serve Breakfast until at least 2:00 pm, please."},{"manager":true,"body":"I wish we could! I love our breakfast too! Our kitchen in Brentwood is a bit small, however, we compromise and serve brunch until 3 on the weekends and holidays."},{"manager":false,"body":"Completely understandable. Have yourself a nice day!"}]},{"type":"Restaurant","city":{"city":"Anchorage","dma_code":743,"latitude":61.2180556,"longitude":-149.9002778,"region":"AK","slug":"anchorage-ak"},"messages":[{"manager":false,"body":"I love this place! But please invest in a better, more reliable WiFi. Thanks!"},{"manager":true,"body":"Thank you for your kind words! We do offer the top speed internet available for our area, however, sometimes it can become a tad bit slower when there are a lot of people on it. We apologize for any inconvenience and appreciate your patronage immensely!"}]},{"type":"Gym","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Locker room is freezing!!!"},{"manager":true,"body":"Thank you, we have adjusted the temperature in both the women and men's locker rooms."}]},{"type":"Restaurant","city":{"city":"Chicago","growth_from_2000_to_2013":"-6.1%","latitude":41.8781136,"longitude":-87.6297982,"population":"2718782","rank":"3","state":"Illinois"},"messages":[{"manager":false,"body":"We love this place! Yummy and convenient."},{"manager":true,"body":"😀makes me happy to hear! Hope to see you soon"}]},{"type":"Restaurant","city":{"city":"Los Angeles","growth_from_2000_to_2013":"4.8%","latitude":34.0522342,"longitude":-118.2436849,"population":"3884307","rank":"2","state":"California"},"messages":[{"manager":false,"body":"Had the best latte! Love this place keep up the good work!"},{"manager":true,"body":"Thanks a lot, we appreciate that immensely! Glad to hear you enjoyed your latte and we hope to have you back again soon."}]},{"type":"Gym","city":{"city":"San Diego","growth_from_2000_to_2013":"10.5%","latitude":32.715738,"longitude":-117.1610838,"population":"1355896","rank":"8","state":"California"},"messages":[{"manager":false,"body":"Love the new steam room. Thank you for fixing!"},{"manager":true,"body":"Love that you love it!"}]},{"type":"Restaurant","city":{"city":"Chicago","growth_from_2000_to_2013":"-6.1%","latitude":41.8781136,"longitude":-87.6297982,"population":"2718782","rank":"3","state":"Illinois"},"messages":[{"manager":false,"body":"Our server was Michelle. So friendly. Very intuitive, happy, and positive vibe. Made our night so comfortable!"},{"manager":true,"body":"Thank you very much for your comments. Michelle is one of our top servers and we are blessed to have her working for us for 10 years. I'm sure she will appreciate your feedback!"}]},{"type":"Restaurant","city":{"city":"Philadelphia","growth_from_2000_to_2013":"2.6%","latitude":39.9525839,"longitude":-75.1652215,"population":"1553165","rank":"5","state":"Pennsylvania"},"messages":[{"manager":false,"body":"Love the fact that you don't have loud music playing in the restaurant!"},{"manager":true,"body":"Thanks, we're glad to hear that you appreciate the ambiance and we are grateful for your feedback. Hope you will join us again soon!"}]},{"type":"Restaurant","city":{"city":"Austin","growth_from_2000_to_2013":"31.7%","latitude":30.267153,"longitude":-97.7430608,"population":"885400","rank":"11","state":"Texas"},"messages":[{"manager":false,"body":"Would be really cool if there were some newspapers available to the customers such as the LA or NY times. Keep up the good work!"},{"manager":true,"body":"We will look into it! Thanks for your feedback and for coming in. Enjoy your thanksgiving."}]},{"type":"Other","city":{"city":"Los Angeles","growth_from_2000_to_2013":"4.8%","latitude":34.0522342,"longitude":-118.2436849,"population":"3884307","rank":"2","state":"California"},"messages":[{"manager":false,"body":"Kori does a wonderful manicure/pedicure. She is friendly, professional, attentive to detail, and gives great massage."},{"manager":true,"body":"Thank you for your feedback and for coming in! I will pass along your kind words. "},{"manager":false,"body":"Thanks! I also love the music you play. Very classy and relaxing."},{"manager":true,"body":"Wonderful! We are so happy to hear such positive feedback. Thank you, again."}]},{"type":"Restaurant","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Tables are dirty"},{"manager":true,"body":"You got it, we'll take care of it. Thank you for bringing it to our attention."}]},{"type":"Other","city":{"city":"Jacksonville","growth_from_2000_to_2013":"14.3%","latitude":30.3321838,"longitude":-81.65565099999999,"population":"842583","rank":"13","state":"Florida"},"messages":[{"manager":false,"body":"I've been a long time client of Tom. He always gives 110%"},{"manager":true,"body":"Thank you for letting us know and for being a loyal client!"}]},{"type":"Gym","city":{"city":"Chicago","growth_from_2000_to_2013":"-6.1%","latitude":41.8781136,"longitude":-87.6297982,"population":"2718782","rank":"3","state":"Illinois"},"messages":[{"manager":false,"body":"Would you guys mind dropping the shades by the hamstring machine?"},{"manager":true,"body":"Sure, taking care of it now!"}]},{"type":"Restaurant","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Great food, but I think the small portions are going to hurt you guys. Good luck!"},{"manager":true,"body":"Thanks for your feedback! We are launching bowls and burritos in the upcoming weeks as well. We hope you'll be back to check it out. Thanks so much for coming in."}]},{"type":"Gym","city":{"city":"Jacksonville","growth_from_2000_to_2013":"14.3%","latitude":30.3321838,"longitude":-81.65565099999999,"population":"842583","rank":"13","state":"Florida"},"messages":[{"manager":false,"body":"Awesome music this morning - refreshing change from usual!"},{"manager":true,"body":"Glad you approve!"}]},{"type":"Restaurant","city":{"city":"San Francisco","growth_from_2000_to_2013":"7.7%","latitude":37.7749295,"longitude":-122.4194155,"population":"837442","rank":"14","state":"California"},"messages":[{"manager":false,"body":"Love your place but the smell of cleaning solution is way too strong. Overwhelming to eat and breath in cleaning solution. Would make me not want to come back even though your tacos are great."},{"manager":true,"body":"Sorry about that. We will be more mindful of cleaning at appropriate times. Thanks for letting us know and glad you enjoyed you tacos :)"}]},{"type":"Restaurant","city":{"city":"Houston","growth_from_2000_to_2013":"11.0%","latitude":29.7604267,"longitude":-95.3698028,"population":"2195914","rank":"4","state":"Texas"},"messages":[{"manager":false,"body":"Great breakfast. Appreciate the gluten free options. Waitress didn't write order down, and brought wrong potatoes. However, other waitress brought correct potatoes with no charge and let us keep the original that were brought. Nice!"},{"manager":true,"body":"Sorry about the potatoes. We are glad they took care of you. Hope you had a great breakfast and thank you for the feedback."}]},{"type":"Restaurant","city":{"city":"Dallas","growth_from_2000_to_2013":"5.6%","latitude":32.7766642,"longitude":-96.79698789999999,"population":"1257676","rank":"9","state":"Texas"},"messages":[{"manager":false,"body":"Your Westwood location is out of diet sodas and you don't offer tap water?? I won't be back. Too bad. The tacos are good."},{"manager":true,"body":"Thanks for reaching out. We are brand new and still in the process of installing our water filtration system, a will have tap water available shortly. I'd love to offer you a bottle of water on us if you're still there :). Glad you enjoyed the tacos and thank you for coming in!"},{"manager":false,"body":"OK, thank you! We will be back."}]},{"type":"Restaurant","city":{"city":"San Diego","growth_from_2000_to_2013":"10.5%","latitude":32.715738,"longitude":-117.1610838,"population":"1355896","rank":"8","state":"California"},"messages":[{"manager":false,"body":"Ella delivered superb service today! Kudos and thank you!"},{"manager":true,"body":"Ella is amazing! Glad you reached out to us - see you soon!"}]},{"type":"Restaurant","city":{"city":"Honolulu","dma_code":744,"latitude":21.3069444,"longitude":-157.8583333,"region":"HI","slug":"honolulu-hi"},"messages":[{"manager":false,"body":"Great rosemary chicken sandwich. Thank you"},{"manager":true,"body":"That's my favorite sandwich too! Thank you for coming in and sharing!"}]},{"type":"Gym","city":{"city":"Indianapolis","growth_from_2000_to_2013":"7.8%","latitude":39.768403,"longitude":-86.158068,"population":"843393","rank":"12","state":"Indiana"},"messages":[{"manager":false,"body":"I really think... it would be great if you could Turn your Music down in here so that I can listen to my own music without blowing my ears out."},{"manager":true,"body":"Which area of the club are you in?"},{"manager":false,"body":"I'm in the general space"},{"manager":true,"body":"Ok! Will adjust levels now. Thank you for the feedback."}]},{"type":"Restaurant","city":{"city":"Los Angeles","growth_from_2000_to_2013":"4.8%","latitude":34.0522342,"longitude":-118.2436849,"population":"3884307","rank":"2","state":"California"},"messages":[{"manager":false,"body":"I used  to come here often...when you closed for construction it came off my radar. A coworker suggested meeting here & I'm reminded of why i loved it! #greatservice"},{"manager":true,"body":"So glad to hear it! Welcome back!"}]},{"type":"Restaurant","city":{"city":"Austin","growth_from_2000_to_2013":"31.7%","latitude":30.267153,"longitude":-97.7430608,"population":"885400","rank":"11","state":"Texas"},"messages":[{"manager":false,"body":"Great breakfast. Appreciate the gluten free options. Waitress didn't write order down, and brought wrong potatoes. However, other waitress brought correct potatoes with no charge and let us keep the original that were brought. Nice!"},{"manager":true,"body":"Sorry about the potatoes. We are glad they took care of you. Hope you had a great breakfast and thank you for the feedback."}]}])
  .filter('stripToken', function(){
    return function(input){
      return input.replace(/^@\d\d\d\s+/, '');
    };
  })
  .controller('SubmissionController', ['$scope', '$http', 'AppContext', function($scope, $http, AppContext){
    var self = this;
    var form = this.mobilesubmission;

    this.onSubmit = function($event){
      $event.preventDefault();
      $http.post(AppContext+'ext/welcome',{mobile:self.mobile});
      self.mobile = '';
      $('form').addClass('submitted');
    };
  }])
  ;
}());
